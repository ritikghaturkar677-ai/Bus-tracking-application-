# VIT Bus Tracker

## Run locally (Chrome)
Double-click `index.html` -> opens in Chrome. 3 routes (Zahid Sir, Zahur Sheikh, Rakhunde Sir) in **Demo mode**
(buses move automatically, no internet backend needed).

## Edit
Open `index.html` in a text editor. Drivers, phone numbers, stops and minutes are in the `BUSES` block at the top of the script.

## Real GPS
See `LIVE_TRACKING_SETUP.md`.
