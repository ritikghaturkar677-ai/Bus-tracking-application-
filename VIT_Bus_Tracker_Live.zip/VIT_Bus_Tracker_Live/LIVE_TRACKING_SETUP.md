# Live GPS setup (Firebase, free)

1. console.firebase.google.com -> new project.
2. Build -> Realtime Database -> Create.
3. Build -> Authentication -> Email/Password -> enable; add 3 users (one per driver).
4. Project settings -> Web app -> copy config.
5. Paste config in `driver.html` (FIREBASE_CONFIG) and in `index.html` (FIREBASE_CONFIG, replace `null`).
6. In `index.html` replace the placeholder `COORDS` with real lat,lng of every stop (Google Maps: long-press a stop).
7. Each driver opens `driver.html`, logs in once; the screen shows his UID.
8. Realtime Database -> Rules -> paste and Publish:

```
{
  "rules": {
    "bus1": { ".read": true, ".write": "auth != null && auth.uid === 'DRIVER1_UID'" },
    "bus2": { ".read": true, ".write": "auth != null && auth.uid === 'DRIVER2_UID'" },
    "bus3": { ".read": true, ".write": "auth != null && auth.uid === 'DRIVER3_UID'" }
  }
}
```

9. Run: GPS needs HTTPS or localhost.
   - On PC test: in this folder run `python -m http.server 8000`, open http://localhost:8000/driver.html and /index.html
   - For phones: upload folder to Firebase Hosting (`firebase init hosting`, `firebase deploy`) -> https link.
10. Driver: Login -> select route -> Start Trip (keep screen on). Students see the bus on index.html.
